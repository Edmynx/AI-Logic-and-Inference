# COSC 76, Fall 2020, PA-5, Edmund Aduse Poku
# README FILE
1) Unzip the provided zip file and put all the necessary modules in one project folder. The modules needed are GSAT.py, SAT.py, and all the given files in the assignment. 

2) Open the solve\_sodoku.py file and, on the line that creates the solver object, set the solver module to use: GSATSAT(sys.argv[1]) means that when the file is executed at the command prompt the GSAT solver module should be used. SAT(sys.argv[1]) indicates that the SAT solver module should be used.

3) Now, open a terminal and run the following commmand to solve the input cnf using the set solver module: "python3 ./solve_sudoku.py <name of cnf file to use>"

